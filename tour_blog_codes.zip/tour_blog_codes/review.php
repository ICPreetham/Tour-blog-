<?php
define('DIR','');
require_once DIR . 'config.php';
$admin = new Admin();


?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Manjunath Tours and Travels</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.php"><i class="icon-airplane"></i>Travel</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li ><a href="index.php">Home</a></li>
							<!-- <li>
								<a href="vacation.html" class="fh5co-sub-ddown">Vacations</a>
								<ul class="fh5co-sub-menu">
									<li><a href="#">Family</a></li>
									<li><a href="#">CSS3 &amp; HTML5</a></li>
									<li><a href="#">Angular JS</a></li>
									<li><a href="#">Node JS</a></li>
									<li><a href="#">Django &amp; Python</a></li>
								</ul>
							</li> -->
							<li><a href="packeges.php">Packages</a></li>
							<li><a href="guides.php">Guides</a></li>
							<li><a href="vehicles.php">Vehicles</a></li>
							<li><a href="drivers.php">Driver</a></li>
							<li><a href="blog.php">Blog</a></li>
							<li class="active"><a href="review.php">Review</a></li>
							<li><a href="contact.php">Contact</a></li>

						<?php
									if(!isset( $_SESSION['uid'])){
							?>
							<li><a href="#"  data-toggle="modal" data-target=".myModal">Login</a></li>
							<li><a href="#"  data-toggle="modal" data-target=".myModal2">Register</a></li>
							<?php } ?>
							<?php
									if(isset( $_SESSION['uid'])){
							?>
								<li><a href="Controller/logout.php" >Logout</a></li><?php } ?>
						</ul>
					</nav>
				</div>
			</div>
		</header>
        <style>
						.modal {
							text-align: center;
					
						}
					
						@media screen and (min-width: 768px) {
							.modal:before {
								display: inline-block;
								vertical-align: middle;
							}
						}
					
						.modal-dialog {
							display: inline-block;
							text-align: left;
							vertical-align: middle;
						}
					
						.modal-content {
							padding: 20px;
						}
					</style>

                    	<div class="review modal fade" data-backdrop="false" style="background-color: rgba(0, 0, 0, 0.5);" tabindex="-1"
						role="dialog" aria-labelledby="myModalLabel">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
											aria-hidden="true">&times;</span></button>
									<center>
										<h3 class="modal-title" id="myModalLabel" style="color: #F78536;font-weight: bold;">Review</h3>
									</center>
									
								</div>
								<div class="modal-body">
									<form action="Controller/insert.php" method="post">
										
										<div class="form-group">
											<label for=""> </label>
											<textarea rows="4" required class="form-control" name="rev" id=""></textarea>
										</div>
					
								</div>
								<div class="modal-footer">
									<br>
                                  
                                    <?php
                                    
									if(!isset( $_SESSION['uid'])){
							        ?>
									<input type="submit" disabled value="Send" name="review" class="btn btn-primary form-control">
                                    <?php
                                    }else{ ?>
                                <input type="submit" value="Send" name="review" class="btn btn-primary form-control">
                                    
                                    <?php
                                    }
                                    ?>
								</div>
								</form>
							</div>
						</div>
					</div>
					
					<div class="myModal modal fade" data-backdrop="false" style="background-color: rgba(0, 0, 0, 0.5);" tabindex="-1"
						role="dialog" aria-labelledby="myModalLabel">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
											aria-hidden="true">&times;</span></button>
									<center>
										<h3 class="modal-title" id="myModalLabel" style="color: #F78536;font-weight: bold;">LOGIN</h3>
									</center>
									
								</div>
								<div class="modal-body">
									<form action="Controller/verify.php" method="post">
										<div class="form-group">
											<label for="">Enter Email-ID : </label>
											<input type="email" required class="form-control" name="email" id="">
										</div>
										<div class="form-group">
											<label for="">Enter Password : </label>
											<input type="password" required class="form-control" name="pass" id="">
										</div>
					
								</div>
								<div class="modal-footer">
									<br>
									<input type="submit" value="login" name="login" class="btn btn-primary form-control">
								</div>
								</form>
							</div>
						</div>
					</div>
					<div class="myModal2 modal fade" data-backdrop="false" style="background-color: rgba(0, 0, 0, 0.5);" tabindex="-1"
						role="dialog" aria-labelledby="myModalLabel">
						<div class="modal-dialog" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
											aria-hidden="true">&times;</span></button>
									<center>
										<h3 class="modal-title" id="myModalLabel" style="color: #F78536;font-weight: bold;" >REGISTER</h3>
									</center>
									
								</div>
								<div class="modal-body">
										<ul class="nav nav-tabs" role="tablist">
											<li role="presentation" class="active">
												<a href="#cust" aria-controls="cust" role="tab" data-toggle="tab">CUSTOMER</a>
											</li>
											<li role="presentation">
												<a href="#driver" aria-controls="driver" role="tab" data-toggle="tab">DRIVER</a>
											</li>
											<li role="presentation">
												<a href="#guide" aria-controls="guide" role="tab" data-toggle="tab">GUIDE</a>
											</li>
										</ul>
										
										<!-- Tab panes -->
										<div class="tab-content">
											<div role="tabpanel" class="tab-pane active" id="cust">
												<form action="Controller/insert.php" method="post">
													<div class="form-group">
														<label for=""> Name : </label>
														<input type="text" required class="form-control" name="name" id="">
													</div>
													<div class="form-group">
														<label for=""> Email-ID : </label>
														<input type="email" required class="form-control" name="email" id="">
													</div>
													<div class="form-group">
														<label for=""> Password : </label>
														<input type="password" required class="form-control" name="pass" id="">
													</div>
													<div class="form-group">
														<label for=""> Phone Numebr : </label>
														<input type="text" maxlength="10" required class="form-control" name="phone" id="">
													</div>
													<div class="form-group">
														<label for=""> Address : </label>
														<textarea rows="3" required class="form-control" name="add" id=""></textarea>
													</div>
													<div class="form-group">
														<label for="">Gender : </label> &nbsp;&nbsp;
														<input type="radio" required value="Male" name="gender" id="" checked> Male&nbsp;&nbsp;
														<input type="radio" required value="Female" name="gender" id=""> Female
													</div>
													<div class="form-group">
														<label for="">Date Of Birth : </label>
														<input type="date" required class="form-control" name="dob" id="">
													</div>
													<div class="form-group">
														<input type="submit" required class="form-control btn btn-primary" value="REGISTER" name="custreg" id="">
													</div>
												
												</form>

											</div>
										
											<div role="tabpanel" class="tab-pane" id="driver">
												<form action="Controller/insert.php" enctype="multipart/form-data" method="post">
													<div class="form-group">
														<label for=""> Name : </label>
														<input type="text" required class="form-control" name="name" id="">
													</div>
													<div class="form-group">
														<label for=""> Email-ID : </label>
														<input type="email" required class="form-control" name="email" id="">
													</div>
													<div class="form-group">
														<label for=""> Password : </label>
														<input type="password" required class="form-control" name="pass" id="">
													</div>
													<div class="form-group">
														<label for=""> Phone Numebr : </label>
														<input type="text" maxlength="10" required class="form-control" name="phone" id="">
													</div>
													<div class="form-group">
														<label for=""> Ammount : </label>
														<input type="text"  required class="form-control" name="ammount" id="">
													</div>
													<div class="form-group">
														<label for=""> Profile Picture : </label>
														<input type="file" required class="form-control" name="propic" id="">
													</div>
													<div class="form-group">
														<label for=""> ID Proof : </label>
														<input type="file" required class="form-control" name="idproof" id="">
													</div>
													<div class="form-group">
														<label for=""> Driving Licence Proof : </label>
														<input type="file" required class="form-control" name="driveproof" id="">
													</div>
													<div class="form-group">
														<input type="submit" required class="form-control btn btn-primary" value="REGISTER" name="drivereg" id="">
													</div>
												
												</form>

											</div>
										
											<div role="tabpanel" class="tab-pane" id="guide">
												<form action="Controller/insert.php" enctype="multipart/form-data"  method="post">
													<div class="form-group">
														<label for=""> Name : </label>
														<input type="text" required class="form-control" name="name" id="">
													</div>
													<div class="form-group">
														<label for=""> Email-ID : </label>
														<input type="email" required class="form-control" name="email" id="">
													</div>
													<div class="form-group">
														<label for=""> Password : </label>
														<input type="password" required class="form-control" name="pass" id="">
													</div>
													<div class="form-group">
														<label for=""> Phone Numebr : </label>
														<input type="text" maxlength="10" required class="form-control" name="phone" id="">
													</div>
													<div class="form-group">
														<label for=""> Ammount : </label>
														<input type="text" required class="form-control" name="ammount" id="">
													</div>
													<div class="form-group">
														<label for=""> Experience : </label>
														<input type="number" required class="form-control" name="exp" id="">
													</div>
													<div class="form-group">
														<label for=""> Profile Picture : </label>
														<input type="file" required class="form-control" name="propic" id="">
													</div>
													<div class="form-group">
														<label for=""> ID Proof : </label>
														<input type="file" required class="form-control" name="idproof" id="">
													</div>
													<div class="form-group">
														<label for=""> Description : </label>
														<textarea rows="3" required class="form-control" name="desc" id=""></textarea>
													</div>
													
													<div class="form-group">
														<input type="submit" required class="form-control btn btn-primary" value="REGISTER" name="guidreg" id="">
													</div>
												
												</form>
											</div>
										</div>

									
					
								</div>
			

							</div>
						</div>
					</div>

		<!-- end:header-top -->

		

		<div id="fh5co-testimonial" style="background-image:url(images/img_bg_1.jpg);">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Reviews</h2> <hr />
				</div>
                <a href="#" data-toggle="modal" data-target=".review" style="background-color:#00ad6c;" class="btn btn-success" > Review</a>
			</div>
            
			<div class="row">

                <?php
                $stmt = $admin -> ret("SELECT * FROM `reivies` ORDER BY `r_id` DESC");
                $i = 0;
                while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){ 
                    $i++;
                    $cid = $row['c_id'];
                    $astmt = $admin -> ret("SELECT * FROM `customer` WHERE `c_id` = '$cid' ");
                    $arow = $astmt -> fetch(PDO::FETCH_ASSOC);
                
                ?>

				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quotes-right"></i></span></span>
							<p>&ldquo;<?= $row['review']?>.&rdquo;</p>
						</blockquote>
						<p class="author"><?= $arow['c_name']?>  <span class="subtext"><?= $row['r_date']?></span></p>
					</div>
					
				</div>
				
                <?php
                    }
                ?>
                             <?php
                          if ($i == 0) {
                                              ?>
                                   
                                                  <div colspan="100%" class="alert alert-success text-center">
                                                      <b>No Reviews Found</b>
                                                  </div>
                                           
                                          <?php } ?>
                
            </div>
		</div>
	</div>
	


		<?php include 'footer.php'; ?>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>

