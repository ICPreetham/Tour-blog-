<?php
define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();

if(!isset($_SESSION['uid'])){
	$admin -> redirect1('../index.php');
}
$id = $_SESSION['uid'];
$stmt = $admin -> ret("SELECT * FROM `guides` WHERE `g_id` = '$id'");
$row = $stmt -> fetch(PDO::FETCH_ASSOC);


?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manjunath Tours and travels</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
     <?php 
      include 'navbar.php'; 
      include 'sidebar.php'; 
      
      ?> 
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Profile</h2>   
                        <h5>Welcome <?= $_SESSION['name']?> , Love to see you back. </h5> <hr>
       
<!------ Include the above in your HEAD tag ---------->

<style>
.pos{
    position: relative;
    left:250px;
}
</style>

<div class="container pos">
    <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-8">
            <div class="well well-sm">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                        <img src="../Controller/<?= $row['profile_photo']?>" alt="" class="img-rounded img-responsive" />
                    </div>
                    <div class="text-center col-sm-6 col-md-8">
                    <form action="../Controller/update.php" method="post">
                        <h4> <i class="glyphicon glyphicon-search"></i>  <input size="21" type="text" value=" <?= $row['g_name']?>" name="name" id="">
                          </h4>
                        <p>
                            <i class="glyphicon glyphicon-envelope"></i> <input size="26" type="text" value="<?= $row['g_email']?>" name="mail" id=""> 
                            <br />
                            <br />
                            <i class="glyphicon glyphicon-phone"></i> <input size="26" type="text" value=" <?= $row['phone_number']?>" name="ph" id=""> 
                            <br />
                            <br />
                            <i class="glyphicon glyphicon-gift"></i> Fees : <input size="20" type="text" value=" <?= $row['g_amount']?>" name="am" id="am"> 
                            <br />
                            <br />
                              <i class="glyphicon glyphicon-arrow-up"></i> Experience : <input size="14" type="text" value=" <?= $row['g_experience']?>" name="exp" id="am"> 
                            <br />
                            <br /> 
                             <i class="glyphicon glyphicon-pencil"></i> Description : <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                               <textarea class="form-control"  rows="3"name="desc" id="am"><?= $row['g_description']?></textarea> 
                          
                            
                             </p>
                        <!-- Split button -->
                        <div class="btn-group">
                            <button  type="submit" name="updateguid" class="btn btn-primary">
                                Update</button>
                                </form>  </div> 
                         <br>
                         <br>
                            <form style="border:2px solid lightblue; border-radius : 10px ;padding:10px;" enctype="multipart/form-data" action="../Controller/update.php" method="post">
                                <label for="" class="label-control"> Change Profile Picture</label>  <br>  
                                <input required type="file" name="propic" class="form-control"><br>
                                <input type="submit" name="guidchangepropiccl" value="Change" class="btn ">
                            </form>
                      
                         
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

                    </div>
                </div>
                 <!-- /. ROW  -->
         
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
