-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2021 at 08:42 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `b_id` int(11) NOT NULL,
  `b_name` varchar(30) NOT NULL,
  `b_image1` varchar(200) NOT NULL,
  `b_image2` varchar(200) NOT NULL,
  `b_image3` varchar(200) NOT NULL,
  `b_desc` varchar(2000) NOT NULL,
  `b_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`b_id`, `b_name`, `b_image1`, `b_image2`, `b_image3`, `b_desc`, `b_date`) VALUES
(1, '', 'fs', '', '', '', '0000-00-00'),
(2, 'f', '', '', '', '', '0000-00-00'),
(3, 'sdsafds', 'image/Screenshot (1).png', 'image/Screenshot (11).png', 'image/', 'dfsdfdsgsafs s sgda ', '2021-05-05'),
(4, 'fsfsdf', 'image/Screenshot (7).png', 'image/', 'image/', 'gdgdf gfdg dfg fdh fdh h', '2021-05-05'),
(5, 'fsfsdf', 'image/Screenshot (7).png', 'image/', 'image/', 'gdgdf gfdg dfg fdh fdh h', '2021-05-05'),
(6, 'fsfsdf', 'image/Screenshot (7).png', '', '', 'gdgdf gfdg dfg fdh fdh h', '2021-05-05'),
(7, 'fsfsdf', 'image/Screenshot (7).png', '', '', 'gdgdf gfdg dfg fdh fdh h', '2021-05-05'),
(8, 'fsfsdf', 'image/Screenshot (7).png', '', '', 'gdgdf gfdg dfg fdh fdh h', '2021-05-05'),
(9, 'fsfsdf', 'image/Screenshot (7).png', '', '', 'gdgdf gfdg dfg fdh fdh h', '2021-05-05'),
(10, 'fdsfsdfasf', 'image/Screenshot (18).png', 'image/Screenshot (11).png', 'image/Screenshot (11).png', 'fdsdsfadgfdgaf', '2021-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `blog_comments`
--

CREATE TABLE `blog_comments` (
  `bc_id` int(11) NOT NULL,
  `b_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `c_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog_comments`
--

INSERT INTO `blog_comments` (`bc_id`, `b_id`, `c_id`, `comment`, `c_date`) VALUES
(1, 10, 8, 'dshfjgsy gshjf gds hfgsdhg fhsdagf ydsgf hasgf sdgfhgadskhf ds', '2021-05-05'),
(2, 10, 8, 'dshfjgsy gshjf gds hfgsdhg fhsdagf ydsgf hasgf sdgfhgadskhf ds', '2021-05-05'),
(5, 10, 8, 'dsadsadASDs dsa SD fdsf fdgd fg g  g', '2021-05-05');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(20) NOT NULL,
  `c_email_id` varchar(35) NOT NULL,
  `c_phone_no` bigint(10) NOT NULL,
  `c_gender` varchar(10) NOT NULL,
  `c_address` varchar(30) NOT NULL,
  `c_dob` date NOT NULL,
  `c_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_name`, `c_email_id`, `c_phone_no`, `c_gender`, `c_address`, `c_dob`, `c_date`) VALUES
(8, 'Pradeep', 'pradeephegde463@gmail.com', 9874564545, 'Male', 'Karkala', '1997-08-29', '2021-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `d_id` int(11) NOT NULL,
  `d_name` varchar(10) NOT NULL,
  `d_email` varchar(35) NOT NULL,
  `phone_number` bigint(10) NOT NULL,
  `d_amount` int(5) NOT NULL,
  `driving_license` varchar(200) NOT NULL,
  `id_proof` varchar(200) NOT NULL,
  `profile_photo` varchar(200) NOT NULL,
  `d_status` varchar(10) NOT NULL,
  `d_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`d_id`, `d_name`, `d_email`, `phone_number`, `d_amount`, `driving_license`, `id_proof`, `profile_photo`, `d_status`, `d_date`) VALUES
(3, 'Vishak', 'vishak@mail.com', 8745642115, 1000, 'documents/Screenshot_2021-03-16-18-27-18-51.png', 'documents/Screenshot_2021-03-19-10-07-46-58.png', 'profilepics/Screenshot (18).png', 'Accepted', '2021-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `driver_booking`
--

CREATE TABLE `driver_booking` (
  `db_id` int(11) NOT NULL,
  `d_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `place` varchar(250) NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `stutus` varchar(11) NOT NULL,
  `d_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `driver_booking`
--

INSERT INTO `driver_booking` (`db_id`, `d_id`, `c_id`, `place`, `from`, `to`, `stutus`, `d_date`) VALUES
(4, 3, 8, 'sdsad', '2021-05-03', '2021-05-04', '', '2021-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `guides`
--

CREATE TABLE `guides` (
  `g_id` int(11) NOT NULL,
  `g_name` varchar(20) NOT NULL,
  `g_email` varchar(35) NOT NULL,
  `phone_number` bigint(10) NOT NULL,
  `g_experience` int(5) NOT NULL,
  `profile_photo` varchar(200) NOT NULL,
  `g_description` varchar(400) NOT NULL,
  `id_proof` varchar(200) NOT NULL,
  `g_amount` int(11) NOT NULL,
  `g_status` varchar(10) NOT NULL,
  `g_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guides`
--

INSERT INTO `guides` (`g_id`, `g_name`, `g_email`, `phone_number`, `g_experience`, `profile_photo`, `g_description`, `id_proof`, `g_amount`, `g_status`, `g_date`) VALUES
(2, '  Nithin', 'nithin@mail.com', 8784156456, 6, 'profilepics/Screenshot (95).png', 'fsdfdsfsafdsfsadfdsagfa', 'documents/Screenshot_2021-03-19-10-07-46-58.png', 1500, 'Accepted', '2021-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `guide_booking`
--

CREATE TABLE `guide_booking` (
  `gb_id` int(11) NOT NULL,
  `g_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `place` varchar(250) NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `b_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `l_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email_id` varchar(35) NOT NULL,
  `password` varchar(2000) NOT NULL,
  `c_date` date NOT NULL,
  `roll` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`l_id`, `name`, `email_id`, `password`, `c_date`, `roll`) VALUES
(1, 'Admin', 'admin@mail.com', '$2y$10$dR.Fp4Zcu/8IUYMfkGWENuXUjO1Qk4hhYNVRaoashuTInGxB.l86G', '2021-04-30', 'a'),
(7, 'Pradeep', 'pradeephegde463@gmail.com', '$2y$10$kza4uULa5KV5O9maa441s.F.bltEQkIQ1CLO8Ro7rddSMRFceQdPu', '2021-04-30', 'c'),
(8, 'Vishak', 'vishak@mail.com', '$2y$10$sNzsno6N7lDVyC2yJq9v3.gWjYLI7tVkO3eJ8ZJW5KMH8K600Ghmi', '2021-04-30', 'd'),
(9, 'Nithin', 'nithin@mail.com', '$2y$10$7wWAOHRpdlK58az.qI1yrOVk6qnmDMTozpSood5EE3lBf61Lf2tiq', '2021-05-01', 'g');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(20) NOT NULL,
  `p_amount` int(10) NOT NULL,
  `p_no_of_days` int(10) NOT NULL,
  `p_start_date` date NOT NULL,
  `p_start_place` varchar(20) NOT NULL,
  `p_seats_available` int(5) NOT NULL,
  `p_image` varchar(200) NOT NULL,
  `p_description` varchar(500) NOT NULL,
  `p_c_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`p_id`, `p_name`, `p_amount`, `p_no_of_days`, `p_start_date`, `p_start_place`, `p_seats_available`, `p_image`, `p_description`, `p_c_date`) VALUES
(6, 'Singapore', 10000, 15, '2021-05-04', 'Mangalore', 26, 'image/IMG_20210316_230813.jpg', 'sfdsdsads df sdf adsf sfdgsfyadsfgdhsgfhagdsfh sdhgf hgHfg hagfytagfygah hfdsgafh gdahsgf hvscdvcgvxcbxznMBCuyg fyegfyeg fyge hfdh gfHDGDFh gdH Fgdhg hgD fdsg feg fyGHJ dhfgh fgd KHDGF hdsfg hdsgfydsgfDGfhjdsgfdsFfds se fsdF ds.\r\n', '2021-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `package_booking`
--

CREATE TABLE `package_booking` (
  `pb_id` int(11) NOT NULL,
  `p_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `no_of_peoples` int(11) NOT NULL,
  `booking_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `package_booking`
--

INSERT INTO `package_booking` (`pb_id`, `p_id`, `c_id`, `no_of_peoples`, `booking_date`) VALUES
(10, 6, 8, 4, '2021-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `c_id` int(10) NOT NULL,
  `p_amount` int(5) NOT NULL,
  `p_date` date NOT NULL,
  `transaction_id` varchar(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `c_id`, `p_amount`, `p_date`, `transaction_id`) VALUES
(4, 8, 4514415, '2021-05-03', 'dsa56d4564'),
(5, 8, 5854, '2021-05-03', 'dsadsadsa'),
(6, 8, 65464, '2021-05-03', 'dsadsadsad'),
(7, 8, 65464, '2021-05-03', 'dsadsadsad'),
(8, 8, 65464, '2021-05-03', 'dsadsadsad'),
(9, 8, 65464, '2021-05-03', 'dsadsadsad'),
(10, 8, 65464, '2021-05-03', 'dsadsadsad'),
(11, 8, 65464, '2021-05-03', 'dsadsadsad'),
(12, 8, 65464, '2021-05-03', 'dsadsadsad'),
(13, 8, 65464, '2021-05-03', 'dsadsadsad'),
(14, 8, 4545, '2021-05-03', 'fdsadsad45'),
(15, 8, 45, '2021-05-03', 'dsadsad'),
(16, 8, 45, '2021-05-03', 'dsadsad'),
(17, 8, 45, '2021-05-03', 'dsadsad'),
(18, 8, 45, '2021-05-03', 'dsadsad'),
(19, 8, 45, '2021-05-03', 'dsadsad');

-- --------------------------------------------------------

--
-- Table structure for table `reivies`
--

CREATE TABLE `reivies` (
  `r_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `review` varchar(500) NOT NULL,
  `r_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reivies`
--

INSERT INTO `reivies` (`r_id`, `c_id`, `review`, `r_date`) VALUES
(1, 8, 'fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h ', '2021-05-04'),
(2, 8, 'fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h ', '2021-05-04'),
(3, 8, 'fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjG\r\n\r\nF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h fdgdsfgs safg hsafg sh', '2021-05-04'),
(4, 8, 'fdgdsfgs safg hsafg shjGF hsgf sYFgfhGDSHJFg dSHFGhd SFhgDS fydsg fhGDHFgdhs h ', '2021-05-04'),
(5, 10, 'dsadsa', '0000-00-00'),
(6, 8, 'dsadsadsad', '2021-05-04');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `v_id` int(11) NOT NULL,
  `v_name` varchar(10) NOT NULL,
  `v_image` varchar(200) NOT NULL,
  `v_description` varchar(400) NOT NULL,
  `v_amount` int(5) NOT NULL,
  `c_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`v_id`, `v_name`, `v_image`, `v_description`, `v_amount`, `c_date`) VALUES
(4, 'Muscle Car', 'image/car2.jpg', 'Very Good Condition.', 4500, '2021-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_booking`
--

CREATE TABLE `vehicle_booking` (
  `vb_id` int(11) NOT NULL,
  `v_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `book_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle_booking`
--

INSERT INTO `vehicle_booking` (`vb_id`, `v_id`, `c_id`, `from`, `to`, `book_date`) VALUES
(2, 4, 8, '2021-05-11', '2021-05-12', '2021-05-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `blog_comments`
--
ALTER TABLE `blog_comments`
  ADD PRIMARY KEY (`bc_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `driver_booking`
--
ALTER TABLE `driver_booking`
  ADD PRIMARY KEY (`db_id`);

--
-- Indexes for table `guides`
--
ALTER TABLE `guides`
  ADD PRIMARY KEY (`g_id`);

--
-- Indexes for table `guide_booking`
--
ALTER TABLE `guide_booking`
  ADD PRIMARY KEY (`gb_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `package_booking`
--
ALTER TABLE `package_booking`
  ADD PRIMARY KEY (`pb_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `reivies`
--
ALTER TABLE `reivies`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `vehicle_booking`
--
ALTER TABLE `vehicle_booking`
  ADD PRIMARY KEY (`vb_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `blog_comments`
--
ALTER TABLE `blog_comments`
  MODIFY `bc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `driver_booking`
--
ALTER TABLE `driver_booking`
  MODIFY `db_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `guides`
--
ALTER TABLE `guides`
  MODIFY `g_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `guide_booking`
--
ALTER TABLE `guide_booking`
  MODIFY `gb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `l_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `package_booking`
--
ALTER TABLE `package_booking`
  MODIFY `pb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `reivies`
--
ALTER TABLE `reivies`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vehicle_booking`
--
ALTER TABLE `vehicle_booking`
  MODIFY `vb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
