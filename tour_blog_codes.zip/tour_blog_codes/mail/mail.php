<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';

require 'vendor/autoload.php';

define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();

$mail = new PHPMailer(true);

try {
    //Server settings Signed out

    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'manjunathtoursandtravels98@gmail.com';                     // SMTP username
    $mail->Password   = '9876543210pP';                               // SMTP password
    $mail->SMTPSecure = 'ssl';;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 465;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
    $roll = "";
    if(isset($_GET['roll'])){
        $roll = $_GET['roll'];
    }


    
    if($roll == "driveraccept"){

        $email=$_GET['custemail'];
        $name=$_GET['cname'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' Driver is Accepted You Request';
        $mail->Body    = '<center><h2>Greetings From Manjunath Tours and Travels. </h2> <h3>Your Driver Has been Confirmed Booking.</h3> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Booking is Confirmed.');
                window.location.href='../driver/driverbooking.php';
            </script>";

        }
     }  
      if($roll == "guideaccept"){

        $email=$_GET['custemail'];
        $name=$_GET['cname'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' Guide is Accepted You Request';
        $mail->Body    = '<center><h2>Greetings From Manjunath Tours and Travels. </h2> <h3>Your Guide Has been Confirmed Booking.</h3> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Booking is Confirmed.');
                window.location.href='../guide/gbooking.php';
            </script>";

        }
     }  
      if($roll == "guidereject"){

        $email=$_GET['custemail'];
        $name=$_GET['cname'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' Guide is Rejected You Request';
        $mail->Body    = '<center><h2>Greetings From Manjunath Tours and Travels. </h2> <h3>Your Guidde Has been Rejected your Booking Please book any another Guide.</h3> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Booking is Rejected.');
                window.location.href='../guide/gbooking.php';
            </script>";

        }
     } 

        if($roll == "driverreject"){

        $email=$_GET['custemail'];
        $name=$_GET['cname'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' Driver is Rejected You Request';
        $mail->Body    = '<center><h2>Greetings From Manjunath Tours and Travels. </h2> <h3>Your Driver Has been Rejected your Booking Please book any another Driver.</h3> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Booking is Rejected.');
                window.location.href='../driver/driverbooking.php';
            </script>";

        }
     }  
 

    if($roll == "custreg"){

        $email=$_GET['email'];
        $name=$_GET['name'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' You have successfully Registered';
        $mail->Body    = '<center><h2>Welcome To Manjunath Tours and Travels. </h2> <h3>You can Login with credintials.</h3> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Successfull Registered Now you Can login.');
                window.location.href='../index.html';
            </script>";

        }
     }  
     
     if($roll == "drivereg"){

        $email=$_GET['email'];
        $name=$_GET['name'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' You have successfully Registered';
        $mail->Body    = '<center><h2>Welcome To Manjunath Tours and Travels. </h2> <h3>Once your documents Will be verified Then you can able to login.</h3><h4>Wait for the next Email <b>Thank You</b></h4> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Successfull Registered Your Documents will be Verified check your Email.');
                window.location.href='../index.html';
            </script>";

        }
     } 
     
     if($roll == "guidreg"){

        $email=$_GET['email'];
        $name=$_GET['name'];
        
        //Recipients
        $mail->setFrom('manjunathtoursandtravels98@gmail.com', 'Manjunath Tours and Travels');
        $mail->addAddress($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Hello '.$name.' You have successfully Registered';
        $mail->Body    = '<center><h2>Welcome To Manjunath Tours and Travels. </h2> <h3>Once your documents Will be verified Then you can able to login.</h3><h4>Wait for the next Email <b>Thank You</b></h4> </center>';
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if($mail->send()){

            echo "<script>alert('Successfull Registered Your Documents will be Verified check your Email.');
                window.location.href='../index.html';
            </script>";

        }
     }


     //do if mail not send's

} catch (Exception $e) {

    echo "<script>alert('Somthing Went Wrong Please check Connection.');
    </script>";


       if($roll == "guideaccept"){
     
               echo "<script>
            window.location.href='../guide/gbooking.php';
        </script>";
    
    }  

       if($roll == "guidereject"){
     
               echo "<script>
            window.location.href='../guide/gbooking.php';
        </script>";
    
    }  

     if($roll == "driveraccept"){
     
               echo "<script>
            window.location.href='../driver/driverbooking.php';
        </script>";
    
    }    
     if($roll == "driverreject"){
     
               echo "<script>
            window.location.href='../driver/driverbooking.php';
        </script>";
    
    }   
    if($roll == "custreg"){
        $stmt = $admin -> cud("DELETE FROM `customer` WHERE `customer`.`c_email_id` = '$email'","deleted");
        if($stmt){
            $stmt = $admin -> cud("DELETE FROM `login` WHERE `login`.`email_id` = '$email'","D");
            if($stmt){
               echo "<script>
            window.location.href='../index.html';
        </script>";
            }
        }

    }    

    
    if($roll == "drivereg"){
        $stmt = $admin -> cud("DELETE FROM `drivers` WHERE `drivers`.`d_email` = '$email'","deleted");
        if($stmt){
            $stmt = $admin -> cud("DELETE FROM `login` WHERE `login`.`email_id` = '$email'","D");
            if($stmt){
               echo "<script>
            window.location.href='../index.html';
        </script>";
            }
        }

    }
 
}
?>
