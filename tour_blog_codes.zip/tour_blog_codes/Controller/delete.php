<?php

define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();

if(isset($_GET['dltdriverbookingid'])){
    $id = $_GET['dltdriverbookingid'];
    $stmt = $admin -> cud("DELETE FROM `driver_booking` WHERE `driver_booking`.`db_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../driver/driverbooking.php';
                </script>";
    }

}

if(isset($_GET['fromadmindltpckgbooking'])){
    $id = $_GET['fromadmindltpckgbooking'];
    $stmt = $admin -> cud("DELETE FROM `package_booking` WHERE `package_booking`.`pb_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/pckgbooking.php';
                </script>";
    }

}

if(isset($_GET['fromadmindltdriverbooking'])){
    $id = $_GET['fromadmindltdriverbooking'];
    $stmt = $admin -> cud("DELETE FROM `driver_booking` WHERE `driver_booking`.`db_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/driverbooking.php';
                </script>";
    }

}

if(isset($_GET['fromadmindltvehiclebooking'])){
    $id = $_GET['fromadmindltvehiclebooking'];
    $stmt = $admin -> cud("DELETE FROM `vehicle_booking` WHERE `vehicle_booking`.`vb_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/vehiclebooking.php';
                </script>";
    }

}
if(isset($_GET['fromadmindltguidegbooking'])){
    $id = $_GET['fromadmindltguidegbooking'];
    $stmt = $admin -> cud("DELETE FROM `guide_booking` WHERE `guide_booking`.`gb_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/guidebooking.php';
                </script>";
    }

}

if(isset($_GET['fromadmindltpckg'])){
    $id = $_GET['fromadmindltpckg'];
    $stmt = $admin -> cud("DELETE FROM `packages` WHERE `packages`.`p_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/viewpckg.php';
                </script>";
    }
}

if(isset($_GET['fromadmindltcust'])){
    $id = $_GET['fromadmindltcust'];
    $stmt = $admin -> cud("DELETE FROM `customer` WHERE `customer`.`c_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/viewcust.php';
                </script>";
    }
}
if(isset($_GET['fromadmindltdriver'])){
    $id = $_GET['fromadmindltdriver'];
    $stmt = $admin -> cud("DELETE FROM `drivers` WHERE `drivers`.`d_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/viewdriver.php';
                </script>";
    }
}

if(isset($_GET['fromadmindltvehicle'])){
    $id = $_GET['fromadmindltvehicle'];
    $stmt = $admin -> cud("DELETE FROM `vehicles` WHERE `vehicles`.`v_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/viewvehicle.php';
                </script>";
    }
}
if(isset($_GET['fromadmindltguide'])){
    $id = $_GET['fromadmindltguide'];
    $stmt = $admin -> cud("DELETE FROM `guides` WHERE `guides`.`g_id` = '$id'","deleted");
    if($stmt){
           echo "<script>alert('Deleted Succuessfully.');
                window.location.href='../admin/viewguide.php';
                </script>";
    }
}

?>