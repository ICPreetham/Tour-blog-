<?php
define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();


if(isset($_POST['login'])){

     $email = $_POST['email'];
     $pass = $_POST['pass'];

     $stmt = $admin->ret("SELECT * FROM `login` WHERE `email_id` = '$email'") ;
    
		$num = $stmt ->rowCount();
		if($num>0){
            
        $row = $stmt ->fetch(PDO::FETCH_ASSOC);
        $id = $row['l_id'];
        $dbpass = $row['password'];

        if(password_verify($pass,$dbpass)){

           
           if($row['roll'] == "c"){

            $astmt = $admin -> ret("SELECT * FROM `customer` WHERE `c_email_id` = '$email'");
            $arow = $astmt -> fetch(PDO::FETCH_ASSOC);
                
                $_SESSION['uid'] = $arow['c_id'];
                $_SESSION['name'] = $row['name'];

                $admin->redirect('../index');

           }elseif($row['roll'] == "g"){

                $astmt = $admin -> ret("SELECT `g_id`,`g_status` FROM `guides` WHERE `g_email` = '$email'");
                $arow = $astmt -> fetch(PDO::FETCH_ASSOC);

                $stutus = $arow['g_status'];
                if($stutus == "Accepted"){
                    $_SESSION['uid'] = $arow['g_id'];
                    $_SESSION['name'] = $row['name'];

                    $admin -> redirect('../guide/index');
                }else{
                    echo "<script>
                            alert('Your Application is Pending Please Wait for somethime.');
                            window.location.href='../index.php';
                        </script>";
                }

               
                

           }elseif($row['roll'] == "d"){

                $astmt = $admin -> ret("SELECT `d_id`,`d_status` FROM `drivers` WHERE `d_email` = '$email'");
                $arow = $astmt -> fetch(PDO::FETCH_ASSOC);
                $stutus = $arow['d_status'];
                if($stutus == "Accepted"){
                    $_SESSION['uid'] = $arow['d_id'];
                    $_SESSION['name'] = $row['name'];

                    $admin -> redirect('../driver/index');
                }else{
                     echo "<script>
                            alert('Your Application is Pending Please Wait for somethime.');
                            window.location.href='../index.php';
                        </script>";
                }


           }else{

                $_SESSION['uid'] = $row['l_id'];
                $_SESSION['name'] = $row['name'];

                $admin->redirect('../admin/index');

           }           
        }else{
            echo "<script>
            alert('You have Entered Wrong Password.');
            window.location.href='../index.php';
            </script>";
        }
        
    }else{
        echo "<script>
        alert('You are Not a Valid User.');
        window.location.href='../index.php';
        </script>";
    }

}

// rolls are assign as for admin : a
// rolls are assign as for guide : g
// rolls are assign as for cust : c
// rolls are assign as for driver : d

   $stutus =NULL;

    if(isset($_GET['driverstutus']) && $_GET['driverstutus'] == "Accepted" ){
        $stutus =  $_GET['driverstutus'];
        $id =  $_GET['id'];
        $stmt = $admin -> cud("UPDATE `drivers` SET `d_status` = '$stutus' WHERE `drivers`.`d_id` = '$id'","updated");
        if($stmt){
             echo "<script>
                alert('Driver Profile is Accepted.');
                 window.location.href='../admin/viewdriver.php';
                </script>";
        }else{
                echo "<script>
                alert('Something went Wrong.');
                 window.location.href='../admin/viewdriver.php';
                </script>";
        }
    }

    if(isset($_GET['driverstutus']) && $_GET['driverstutus'] == "Rejected" ){
        $stutus =  $_GET['driverstutus'];
        $id =  $_GET['id'];
        $stmt = $admin -> cud("UPDATE `drivers` SET `d_status` = '$stutus' WHERE `drivers`.`d_id` = '$id'","updated");
        if($stmt){
             echo "<script>
                alert('Driver Profile is Rejcted .');
                window.location.href='../admin/viewdriver.php';
                </script>";
        }else{
                echo "<script>
                alert('Something went Wrong.');
                 window.location.href='../admin/viewdriver.php';
                </script>";
        }
    }
 
    if(isset($_GET['guidestutus']) && $_GET['guidestutus'] == "Accepted" ){
        $stutus =  $_GET['guidestutus'];
        $id =  $_GET['id'];
        $stmt = $admin -> cud("UPDATE `guides` SET `g_status` = '$stutus' WHERE `guides`.`g_id` = '$id'","updated");
        if($stmt){
             echo "<script>
                alert('Guide Profile is Accepted.');
                 window.location.href='../admin/viewguide.php';
                </script>";
        }else{
                echo "<script>
                alert('Something went Wrong.');
                 window.location.href='../admin/viewguide.php';
                </script>";
        }
    }

    if(isset($_GET['guidestutus']) && $_GET['guidestutus'] == "Rejected" ){
        $stutus =  $_GET['guidestutus'];
        $id =  $_GET['id'];
        $stmt = $admin -> cud("UPDATE `guides` SET `g_status` = '$stutus' WHERE `guides`.`g_id` = '$id'","updated");
        if($stmt){
             echo "<script>
                alert('Guide Profile is Rejcted .');
                window.location.href='../admin/viewguide.php';
                </script>";
        }else{
                echo "<script>
                alert('Something went Wrong.');
                 window.location.href='../admin/viewguide.php';
                </script>";
        }
    }
 
 


?>