<?php
define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();


$uid = $_SESSION['uid'];

    if(isset($_POST['custreg'])){
       
        $email = $_POST['email'];
       
        $stmt = $admin -> ret("SELECT * FROM `customer` WHERE `c_email_id` = '$email'");
        $num = $stmt -> rowCount();
        if($num > 0){
            echo "<script>alert('You Have Already had Account Please Login');
             window.location.href='../index.html';
            </script>";
        }else{
            $name = $_POST['name'];
            $pass = $_POST['pass'];
            $phone = $_POST['phone'];
            $add = $_POST['add'];
            $gender = $_POST['gender'];
            $dob = $_POST['dob'];
            $stmt = $admin -> cud("INSERT INTO `customer` ( `c_name`, `c_email_id`, `c_phone_no`, `c_gender`, `c_address`, `c_dob`, `c_date`)
                                                 VALUES ('".$name."','".$email."','".$phone."','".$gender."','".$add."','".$dob."',NOW())","saved");
            if($stmt){
                $hpass = password_hash($pass,PASSWORD_BCRYPT);
                $roll = "c";
                $stmt = $admin -> cud("INSERT INTO `login` (`name`, `email_id`, `password`, `c_date`, `roll`) 
                                                    VALUES ('".$name."','".$email."','".$hpass."',NOW(),'".$roll."')","saved");
                $admin -> redirect1('../mail/mail.php?name='.$name.'&email='.$email.'&roll=custreg');
            }
        }

      
    }    

    if(isset($_POST['drivereg'])){
        
        $email = $_POST['email'];

        $stmt = $admin -> ret("SELECT * FROM `drivers` WHERE `d_email` = '$email'");
        $num = $stmt -> rowCount();
            if($num > 0){
                echo "<script>alert('You Have Already had Account Please Login');
                window.location.href='../index.html';
                </script>";
            }else{
                $name = $_POST['name'];
                $pass = $_POST['pass'];
                $phone = $_POST['phone'];
                $ammount = $_POST['ammount'];

                $proPicsDir = "profilepics/";
                $docmentDir = "documents/";

                $profile = $proPicsDir . basename($_FILES['propic']['name']);
                $idLoc = $docmentDir . basename($_FILES['idproof']['name']);
                $drivelicLoc = $docmentDir .basename($_FILES['driveproof']['name']);

                move_uploaded_file($_FILES['propic']['tmp_name'],$profile);
                move_uploaded_file($_FILES['idproof']['tmp_name'],$idLoc);
                move_uploaded_file($_FILES['driveproof']['tmp_name'],$drivelicLoc);

                $stutus = "Pending";
                
                   $stmt = $admin -> cud("INSERT INTO `drivers` ( `d_name`, `d_email`, `phone_number`, `d_amount`,
                                             `driving_license`, `id_proof`, `profile_photo`, `d_status`, `d_date`) 
                VALUES('".$name."','".$email."','".$phone."','".$ammount."','".$drivelicLoc."','".$idLoc."','".$profile."','".$stutus."',NOW())","saved");
                    if($stmt){

                        $hpass = password_hash($pass,PASSWORD_BCRYPT);
                        $roll = "d";
                        $stmt = $admin -> cud("INSERT INTO `login` (`name`, `email_id`, `password`, `c_date`, `roll`) 
                                                            VALUES ('".$name."','".$email."','".$hpass."',NOW(),'".$roll."')","saved");
                        $admin -> redirect1('../mail/mail.php?name='.$name.'&email='.$email.'&roll=drivereg');
                    }

        }

    }

    if(isset($_POST['guidreg'])){

        $email = $_POST['email'];
        
        $stmt = $admin -> ret("SELECT * FROM `guides` WHERE `g_email` = '$email'");
        $num = $stmt -> rowCount();
            if($num > 0){
                echo "<script>alert('You Have Already had Account Please Login');
                window.location.href='../index.html';
                </script>";
            }else{
                $name = $_POST['name'];
                $pass = $_POST['pass'];
                $phone = $_POST['phone'];
                $exp = $_POST['exp'];
                $ammount = $_POST['ammount'];
                $desc = $_POST['desc'];

                $proPicsDir = "profilepics/";
                $docmentDir = "documents/";

                $profile = $proPicsDir . basename($_FILES['propic']['name']);
                $idLoc = $docmentDir . basename($_FILES['idproof']['name']);

                move_uploaded_file($_FILES['propic']['tmp_name'],$profile);
                move_uploaded_file($_FILES['idproof']['tmp_name'],$idLoc);

                   $stutus = "Pending";
                
                   $stmt = $admin -> cud("INSERT INTO `guides` ( `g_name`, `g_email`, `phone_number`, `g_experience`, `profile_photo`, `g_description`, `id_proof`, `g_amount`, `g_status`, `g_date`) 
                   VALUES ('".$name."','".$email."','".$phone."','".$exp."','".$profile."','".$desc."','".$idLoc."','".$ammount."','".$stutus."',NOW())","saved");
                    if($stmt){

                        $hpass = password_hash($pass,PASSWORD_BCRYPT);
                        $roll = "g";
                        $stmt = $admin -> cud("INSERT INTO `login` (`name`, `email_id`, `password`, `c_date`,  `roll`) 
                                                            VALUES ('".$name."','".$email."','".$hpass."',NOW(),'".$roll."')","saved");
                        $admin -> redirect1('../mail/mail.php?name='.$name.'&email='.$email.'&roll=guidreg');
                    }



            }
        
    }

    if(isset($_POST['addpckg'])){

        $pname = $_POST['pname'];
        $pammount = $_POST['pammount'];
        $noofdays = $_POST['noofdays'];
        $psdate = $_POST['psdate'];
        $psplace = $_POST['psplace'];
        $ptsavail = $_POST['ptsavail'];
        $pdesc = $_POST['pdesc'];

        $image = "image/";

        $fileloc = $image . basename($_FILES['pimage']['name']);

        move_uploaded_file($_FILES['pimage']['tmp_name'],$fileloc);

        $stmt = $admin -> cud("INSERT INTO `packages` (`p_name`, `p_amount`, `p_no_of_days`, `p_start_date`, `p_start_place`,
                                                         `p_seats_available`, `p_image`, `p_description`, `p_c_date`) 
        VALUES ('".$pname."','".$pammount."','".$noofdays."','".$psdate."','".$psplace."','".$ptsavail."','".$fileloc."','".$pdesc."',NOW())","saved");

        if($stmt){
             echo "<script>alert('New Package Added Succuessfully.');
                window.location.href='../admin/addpckg.php';
                </script>";
        }else{
             echo "<script>alert('Something Went Wrong Please try again.');
                window.location.href='../admin/addpckg.php';
                </script>";
        }
    }  
    
    
    if(isset($_POST['addblog'])){

       $bname = $_POST['bname'];
       $bdesc = $_POST['bdesc'];


        $image = "image/";

        $fileloc1 = $image . basename($_FILES['bimage1']['name']);
        move_uploaded_file($_FILES['bimage1']['tmp_name'],$fileloc1); 

   
        $fileloc2 = $image . basename($_FILES['bimage2']['name']);
        move_uploaded_file($_FILES['bimage2']['tmp_name'],$fileloc2); 
  
      
  
        $fileloc3 = $image . basename($_FILES['bimage3']['name']);
        move_uploaded_file($_FILES['bimage3']['tmp_name'],$fileloc3);

       



        $stmt = $admin -> cud("INSERT INTO `blog` ( `b_name`, `b_image1`, `b_image2`, `b_image3`, `b_desc`, `b_date`) VALUES ('".$bname."','".$fileloc1."','".$fileloc2."','".$fileloc3."','".$bdesc."',NOW())","saved");

        if($stmt){
             echo "<script>alert('New Blog Added Succuessfully.');
                window.location.href='../admin/addblog.php';
                </script>";
        }else{
             echo "<script>alert('Something Went Wrong Please try again.');
                window.location.href='../admin/addblog.php';
                </script>";
        }
    }

    if(isset($_POST['addvehicle'])){
        $vname = $_POST['vname'];
        $vammount = $_POST['vammount'];
        $vdesc = $_POST['vdesc'];

        $image = "image/";

        $fileloc = $image . basename($_FILES['vimage']['name']);

        move_uploaded_file($_FILES['vimage']['tmp_name'],$fileloc);

        $stmt = $admin -> cud("INSERT INTO `vehicles` ( `v_name`, `v_image`, `v_description`, `v_amount`,`c_date`) 
                                VALUES('".$vname."','".$fileloc."','".$vdesc."','".$vammount."',NOW())","saved");

         if($stmt){
             echo "<script>alert('New Vehicle Added Succuessfully.');
                window.location.href='../admin/addvehicle.php';
                </script>";
        }else{
             echo "<script>alert('Something Went Wrong Please try again.');
                window.location.href='../admin/addvehicle.php';
                </script>";
        }
    
    }   
    
    
    if(isset($_POST['comm'])){

        $com = $_POST['com'];
        $bid = $_POST['bid'];

        $stmt = $admin -> cud("INSERT INTO `blog_comments` ( `b_id`, `c_id`, `comment`, `c_date`) VALUES ('".$bid."','".$uid."','".$com."',NOW())","saved");

         if($stmt){
             echo "<script>alert('Comment Posted Successfully.');
                window.location.href='../viewblog.php?id=$bid';
                </script>";
        }else{
             echo "<script>alert('Something Went Wrong Please try again.');
                window.location.href='../viewblog.php?id=$bid';
                </script>";
        }
    
    }

    if(isset($_POST['trance'])){
        $trid = $_POST['trid'];
        $adammount = $_POST['adammount'];
        $no_of_peoples = $_POST['no_of_peoples'];

       
        $stmt = $admin -> cud("INSERT INTO `payment` ( `c_id`, `p_amount`, `p_date`,`transaction_id`) 
        VALUES ('".$uid."','".$adammount."',NOW(),'".$trid."') ","saved");
        if($stmt){
            if(isset($_POST['packageid'])){
                $packageid = $_POST['packageid'];

                $stmt = $admin -> ret("SELECT * FROM `packages` WHERE `p_id` = '$packageid'");
                $row = $stmt -> fetch(PDO::FETCH_ASSOC);
                $p_seats_available = $row['p_seats_available'];
                echo $seat = $p_seats_available - $no_of_peoples ; 

                 $admin -> cud("UPDATE `packages` SET `p_seats_available` = '$seat' WHERE `packages`.`p_id` = '$packageid'","saved");


                $stmt = $admin -> cud("INSERT INTO `package_booking` ( `p_id`, `c_id`, `no_of_peoples` , `booking_date`) 
                VALUES ('".$packageid."','".$uid."','".$no_of_peoples."',NOW())","saved");

                if($stmt){
                    echo "<script>alert('Package Has Been Booked.');
                    window.location.href='../view.php?from=package&pid=$packageid';
                    </script>";
                }
            } 
            if(isset($_POST['vehivcleid'])){
                $vehivcleid = $_POST['vehivcleid'];
                $from = $_POST['from'];
                $to = $_POST['to'];




                  $guidbookeddates = array();
   
        $stmt = $admin -> ret("SELECT `from` , `to` FROM `vehicle_booking` WHERE `v_id` = '$vehivcleid' ");
        $num = $stmt -> rowCount();
        if($num > 0){
           
              while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){
                $databasefromdate = $row['from'];
                $databasetodate = $row['to'];
                $format = 'Y-m-d' ;
               
                $interval = new DateInterval('P1D');

                $realEnd = new DateTime($databasetodate);
                $realEnd->add($interval);

                $period = new DatePeriod(new DateTime($databasefromdate), $interval, $realEnd);

                foreach($period as $date) { 
                    $guidbookeddates[] = $date->format($format); 
                }
        }
        
                $format = 'Y-m-d' ;
                $newDatewebsite = array();
                $interval = new DateInterval('P1D');

                $realEnd = new DateTime($to);
                $realEnd->add($interval);

                $period = new DatePeriod(new DateTime($from), $interval, $realEnd);

                foreach($period as $date) { 
                    $newDatewebsite[] = $date->format($format); 
                }
                
                for($i=0; $i < count($guidbookeddates) ; $i++){
                    if($guidbookeddates[$i] == $newDatewebsite[$i]){
                         echo "<script>alert('Vehicle is already booked by another user your selected date.');
                       window.location.href='../view.php?from=vehicle&vid=$vehivcleid';
                        </script>";
                    }else{
                   
                    $stmt = $admin -> cud("INSERT INTO `vehicle_booking` ( `v_id`, `c_id`, `from`,`to`,`book_date`) 
                VALUES ('".$vehivcleid."','".$uid."','".$from."','".$to."',NOW())","saved");

                if($stmt){
                    echo "<script>alert('Vehicle Has Been Booked.');
                    window.location.href='../view.php?from=vehicle&vid=$vehivcleid';
                    </script>";
                }               
                }
                }
        }
        else{
            
            $stmt = $admin -> cud("INSERT INTO `vehicle_booking` ( `v_id`, `c_id`, `from`,`to`,`book_date`) 
                VALUES ('".$vehivcleid."','".$uid."','".$from."','".$to."',NOW())","saved");

                if($stmt){
                    echo "<script>alert('Vehicle Has Been Booked.');
                    window.location.href='../view.php?from=vehicle&vid=$vehivcleid';
                    </script>";
                } 
        }








               
            }
        }


        

    }

    if(isset($_POST['guidebook'])){

        
         $place = $_POST['place'];
        $to = $_POST['to'];
        $from = $_POST['from'];
        $guidbookeddates = array();
        $guidid = $_POST['guidid'];
        $stmt = $admin -> ret("SELECT `from` , `to` FROM `guide_booking` WHERE `g_id` = '$guidid' ");
        $num = $stmt -> rowCount();
        if($num > 0){
           
              while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){
                $databasefromdate = $row['from'];
                $databasetodate = $row['to'];
                $format = 'Y-m-d' ;
               
                $interval = new DateInterval('P1D');

                $realEnd = new DateTime($databasetodate);
                $realEnd->add($interval);

                $period = new DatePeriod(new DateTime($databasefromdate), $interval, $realEnd);

                foreach($period as $date) { 
                    $guidbookeddates[] = $date->format($format); 
                }
        }
        
                $format = 'Y-m-d' ;
                $newDatewebsite = array();
                $interval = new DateInterval('P1D');

                $realEnd = new DateTime($to);
                $realEnd->add($interval);

                $period = new DatePeriod(new DateTime($from), $interval, $realEnd);

                foreach($period as $date) { 
                    $newDatewebsite[] = $date->format($format); 
                }
                
                for($i=0; $i < count($guidbookeddates) ; $i++){
                    if($guidbookeddates[$i] == $newDatewebsite[$i]){
                         echo "<script>alert('Guide is already booked by another user your selected date.');
                        window.location.href='../view.php?from=guidebook&gid=$guidid';
                        </script>";
                    }else{
                    $place = $_POST['place'];
                    $stmt = $admin -> cud("INSERT INTO `guide_booking` ( `g_id`, `c_id`, `place`, `from`, `to`, `b_date`) 
                    VALUES ('".$guidid."','".$uid."','".$place."','".$from."','".$to."',NOW()) ","saved");
                     echo "<script>alert('Guide is Booked you will get Email notification from gruid if he/she Accepted your Request');
                    window.location.href='../view.php?from=guidebook&gid=$guidid';
                    </script>";                   
                }
                }
        }
        else{
             $stmt = $admin -> cud("INSERT INTO `guide_booking` ( `g_id`, `c_id`, `place`, `from`, `to`, `b_date`) 
            VALUES ('".$guidid."','".$uid."','".$place."','".$from."','".$to."',NOW()) ","saved");
            if($stmt){
                echo "<script>alert('Guide is Booked you will get Email notification from gruid if he/she Accepted your Request');
                window.location.href='../view.php?from=guidebook&gid=$guidid';
                </script>";
            }   
        }
}


    if(isset($_POST['driverbook'])){

        
         $place = $_POST['place'];
        $to = $_POST['to'];
        $from = $_POST['from'];
        $guidbookeddates = array();
        $driverid = $_POST['driverid'];
        $stmt = $admin -> ret("SELECT `from` , `to` FROM `driver_booking` WHERE `d_id` = '$driverid' ");
        $num = $stmt -> rowCount();
        if($num > 0){
           
              while($row = $stmt -> fetch(PDO::FETCH_ASSOC)){
                $databasefromdate = $row['from'];
                $databasetodate = $row['to'];
                $format = 'Y-m-d' ;
               
                $interval = new DateInterval('P1D');

                $realEnd = new DateTime($databasetodate);
                $realEnd->add($interval);

                $period = new DatePeriod(new DateTime($databasefromdate), $interval, $realEnd);

                foreach($period as $date) { 
                    $guidbookeddates[] = $date->format($format); 
                }
        }
        
                $format = 'Y-m-d' ;
                $newDatewebsite = array();
                $interval = new DateInterval('P1D');

                $realEnd = new DateTime($to);
                $realEnd->add($interval);

                $period = new DatePeriod(new DateTime($from), $interval, $realEnd);

                foreach($period as $date) { 
                    $newDatewebsite[] = $date->format($format); 
                }
                
                for($i=0; $i < count($guidbookeddates) ; $i++){
                    if($guidbookeddates[$i] == $newDatewebsite[$i]){
                         echo "<script>alert('Driver is already booked by another user your selected date.');
                        window.location.href='../view.php?from=driverbook&did=$driverid';
                        </script>";
                    }else{
                      
                    $place = $_POST['place'];
                    $stmt = $admin -> cud("INSERT INTO `driver_booking` ( `d_id`, `c_id`, `place`, `from`, `to`, `d_date`) 
                    VALUES ('".$driverid."','".$uid."','".$place."','".$from."','".$to."',NOW()) ","saved");
                     echo "<script>alert('Guide is Booked you will get Email notification from gruid if he/she Accepted your Request');
                    window.location.href='../view.php?from=driverbook&did='$driverid;
                    </script>";                   
                }
                }
        }
        else{
             $stmt = $admin -> cud("INSERT INTO `driver_booking` ( `d_id`, `c_id`, `place`, `from`, `to`, `d_date`) 
            VALUES ('".$driverid."','".$uid."','".$place."','".$from."','".$to."',NOW()) ","saved");
            if($stmt){
                echo "<script>alert('Driver is Booked you will get Email notification from gruid if he Accepted your Request');
                window.location.href='../view.php?from=driverbook&did=$driverid';
                </script>";
            }   
        }
}


if(isset($_POST['review'])){
    $rev = $_POST['rev'];
    $stmt = $admin -> cud("INSERT INTO `reivies` ( `c_id`, `review`, `r_date`) VALUES ('".$uid."','".$rev."',NOW())","saved");
    if($stmt){
         echo "<script>alert('Thank You For Review.');
                window.location.href='../review.php';
                </script>";
    }
}



?>