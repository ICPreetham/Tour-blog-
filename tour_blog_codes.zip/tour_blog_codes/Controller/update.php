<?php

define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();

$uid = $_SESSION['uid'];


if(isset($_POST['update'])){
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $ph = $_POST['ph'];
    $am = $_POST['am'];

    $stmt = $admin -> cud("UPDATE `drivers` SET `d_name` = '$name', `d_email` = '$mail' , `phone_number` = '$ph', `d_amount` = '$am' WHERE `drivers`.`d_id` = '$uid';","updated");
    if($stmt){
         echo "<script>alert('Profile Updated Succussfully');
             window.location.href='../driver/uprofile.php';
            </script>";
    }
}
if(isset($_POST['changepropiccl'])){

    $stmt = $admin -> ret("SELECT * FROM `drivers` WHERE `d_id` = '$uid'");
    $row = $stmt -> fetch(PDO::FETCH_ASSOC);
    $pro = $row['profile_photo'];
    unlink($pro);

    $targetDir = "profilepics/";
    $proloc = $targetDir . basename($_FILES['propic']['name']);
    move_uploaded_file($_FILES['propic']['tmp_name'],$proloc);
    
    $stmt = $admin -> cud("UPDATE `drivers` SET `profile_photo` = '$proloc' WHERE `drivers`.`d_id` = '$uid';","updated");
    if($stmt){
         echo "<script>alert('Profile Picture Updated Succussfully');
             window.location.href='../driver/uprofile.php';
            </script>";
    }
}



if(isset($_POST['updateguid'])){
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $ph = $_POST['ph'];
    $am = $_POST['am'];
    $ex = $_POST['exp'];
    $desc = $_POST['desc'];

    $stmt = $admin -> cud("UPDATE `guides` SET `g_name` = '$name', `g_experience` = '$ex' ,`g_description` = '$desc' ,`g_email` = '$mail' , `phone_number` = '$ph', `g_amount` = '$am' WHERE `guides`.`g_id` = '$uid';","updated");
    if($stmt){
         echo "<script>alert('Profile Updated Succussfully');
             window.location.href='../guide/uprofile.php';
            </script>";
    }
}
if(isset($_POST['guidchangepropiccl'])){

    $stmt = $admin -> ret("SELECT * FROM `guides` WHERE `g_id` = '$uid'");
    $row = $stmt -> fetch(PDO::FETCH_ASSOC);
    $pro = $row['profile_photo'];
    unlink($pro);

    $targetDir = "profilepics/";
    $proloc = $targetDir . basename($_FILES['propic']['name']);
    move_uploaded_file($_FILES['propic']['tmp_name'],$proloc);
    
    $stmt = $admin -> cud("UPDATE `guides` SET `profile_photo` = '$proloc' WHERE `guides`.`g_id` = '$uid';","updated");
    if($stmt){
         echo "<script>alert('Profile Picture Updated Succussfully');
             window.location.href='../guide/uprofile.php';
            </script>";
    }
}


?>