<?php
define('DIR','../');
require_once DIR . 'config.php';
$admin = new Admin();

if(!isset($_SESSION['uid'])){
	$admin -> redirect1('../index.php');
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manjunath Tours and travels</title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <div id="wrapper">
     <?php 
      include 'navbar.php'; 
      include 'sidebar.php'; 
      
      ?> 
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>View Packeges</h2>   <hr />

                        <div class="container">
                             <table class="table">
                                <thead style="background-color:black;color:white;" class="thead-dark">
                                  <tr>
                                  <th scope="col">#</th>
                                  <th scope="col">Package Name</th>
                                  <th scope="col">Package Ammount</th>
                                  <th scope="col">package Tour Days</th>
                                  <th scope="col">Package Start Date</th>
                                  <th scope="col">Package Start Place</th>
                                  <th scope="col">Package Seats Available</th>
                                  <th scope="col">Package Description</th>
                                  <th width="100px" scope="col">Action</th>
                                  </tr>
                                </thead>
                                <tbody>

                                  <?php
                                  $stmt = $admin -> ret("SELECT * FROM `packages` ORDER BY `p_id` DESC ");
                                  $i=0;
                                  while($row = $stmt-> fetch(PDO::FETCH_ASSOC))
                                  {
                                  ?>
                                <tr>
                                  <td><?php echo ++$i; ?></td>
                                  <td><?php echo $row['p_name'] ; ?></td>
                                  <td><?php echo $row['p_amount'] ; ?></td>
                                  <td><?php echo $row['p_no_of_days'] ; ?></td>
                                  <td><?php echo $row['p_start_date'] ; ?></td>
                                  <td><?php echo $row['p_start_place'] ; ?></td>
                                  <td><?php echo $row['p_seats_available'] ; ?></td>
                                  <td><?php echo $row['p_description'] ; ?></td>
                                
                                    
                                  <td><a href="../Controller/delete.php?fromadmindltpckg=<?php echo $row['p_id']; ?>"><button name="dlt" class="btn btn-danger">DELETE</button></a></td>
                                
                                </tr>
                                
                                
                                <?php
                                  }
                                ?>
                                </tbody>
                                  <?php
                          if ($i == 0) {
                                              ?>
                                              <tr>
                                                  <td colspan="100%" class="alert alert-warning text-center">
                                                      No records Found
                                                  </td>
                                              </tr>
                                          <?php } ?>
						</table>
                        </div>
                       
                    </div>
                </div>
               
    </div>
             <!-- /. PAGE INNER  -->
            </div>
         <!-- /. PAGE WRAPPER  -->
        </div>
     <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
      <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    
   
</body>
</html>
