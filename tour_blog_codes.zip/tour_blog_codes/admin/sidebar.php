      <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<br>
			
                    <li>
                        <a class="active-menu"  href="index.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-sitemap fa-3x"></i> Bookings<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="pckgbooking.php">Packeges</a>
                            </li>
                            <li>
                                <a href="driverbooking.php">Drivers</a>
                            </li>
                            <li>
                                <a href="vehiclebooking.php">Vehicle</a>
                            </li>
                            <li>
                                <a href="guidebooking.php">Guides</a>
                            </li>
                        </ul>
                      </li>  
                     <li>
                        <a  href="addpckg.php"><i class="fa fa-desktop fa-3x"></i> Add Package</a>
                    </li>
                     <li  >
                        <a  href="addvehicle.php"><i class="fa fa-table fa-3x"></i> Add Vehicle</a>
                    </li>
                    <li>
                        <a  href="addblog.php"><i class="fa fa-desktop fa-3x"></i> Add Blog</a>
                    </li>
                    <li>
                        <a  href="viewpckg.php"><i class="fa fa-qrcode fa-3x"></i> View packages</a>
                    </li> <li>
                        <a  href="viewcust.php"><i class="fa fa-qrcode fa-3x"></i> View Customers</a>
                    </li>
						   <!-- <li  >
                        <a   href="adddriver.php"><i class="fa fa-bar-chart-o fa-3x"></i> Add Driver</a>
                    </li>	 -->
                      <li  >
                        <a  href="viewdriver.php"><i class="fa fa-table fa-3x"></i> View Drivers</a>
                    </li>
                    
                     <li  >
                        <a  href="viewvehicle.php"><i class="fa fa-table fa-3x"></i> View Vehicles</a>
                    </li>
                    <!-- <li  >
                        <a  href="addguide.php"><i class="fa fa-edit fa-3x"></i> Add guide </a>
                    </li>-->
                     <li  >
                        <a  href="viewguide.php"><i class="fa fa-edit fa-3x"></i> View guides </a>
                    </li>		
					
                  <li>
                        <a  href="blank.php"><i class="fa fa-square-o fa-3x"></i> Blank Page</a>
                    </li>	
                </ul>
               
            </div>
            
        </nav>  